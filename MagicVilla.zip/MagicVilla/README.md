# MagicVilla_API

- Villa API

# MagicVilla_Web

- Villa .NET Core MVC

- Villa API

# MagicVilla_Web

- Villa .NET Core MVC

